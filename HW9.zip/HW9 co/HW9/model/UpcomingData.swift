//
//  UpcomingData.swift
//  HW9
//
//  Created by Joey on 11/29/18.
//  Copyright © 2018 Joey. All rights reserved.
//

import UIKit

class UpcomingData: NSObject {
    var Name:String!
    var Artist: String!
    var Date: Date!
    var Time: String!
    var EventType: String!
    var URL: String!
}
